# Python Calculator
Python package that performs addition, subtraction, multiplication, and division calculations

## Installation
```
$ pip install setupdemo_calculator
```

## Usage
This package requires a valid api key. You can get one from [Setupdemo Developer Guide](https://setupdemo_calc.com/services/developer/api/)

## License
Setupdemo Calculator is released under the MIT license. See LICENSE for details.
*to choose a license https://choosealicense.com/

## Contact
Follow me on twitter [@techumbrae](https://twitter.com/techumbrae)